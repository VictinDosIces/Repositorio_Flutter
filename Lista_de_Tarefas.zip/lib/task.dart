class Task {
  String title;

  Task({required this.title});
}
